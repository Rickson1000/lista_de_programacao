var searchData=
[
  ['aviso_0',['aviso',['../class_sculptor.html#a6925a661f530d429afe49f599da1a756',1,'Sculptor']]]
];
